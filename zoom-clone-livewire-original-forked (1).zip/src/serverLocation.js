const SERVERLOCATION = "https://lr3ti.sse.codesandbox.io";
export default SERVERLOCATION;
